#include <atmel_start.h>
#include <hal_gpio.h>
#include <hal_delay.h>
#include <hal_ext_irq.h>
#include <hpl_dma.h>
//#include "utils.h"
#define TX_Bytes 12
//static uint8_t USART_TX_Buf[TX_Bytes] = "Hello World!";
//static uint8_t USART_TX_Buf[TX_Bytes] = "ABCDEFGHIJKL";
static uint8_t USART_TX_Buf[TX_Bytes] = "AABBCCDDEEFF";

void dmac_channel_0_callback(struct _dma_resource *resource)
{
	//gpio_toggle_pin_level(LED0);	// if led toggles dma works - tested works 
	/* Enable DMA CH-2 */
	//_dma_enable_transaction(2, false);
}

void config_dma_channel_0(void)
{
	struct _dma_resource *dma_res;
	_dma_set_source_address(0, (void *)USART_TX_Buf);
	_dma_set_destination_address(0, (void *)&(((Sercom *)(USART_0.device.hw))->USART.DATA.reg));
	_dma_set_data_amount(0, (uint32_t)(TX_Bytes-11));
	_dma_get_channel_resource(&dma_res, 0);
	/* Set application callback to handle the DMA CH-0 transfer done */
	dma_res->dma_cb.transfer_done = dmac_channel_0_callback;
	_dma_set_irq_state(0, DMA_TRANSFER_COMPLETE_CB, true);
}

void USART_transmit(void){	// gets here
	struct io_descriptor *io;
	usart_async_get_io_descriptor(&USART_0, &io);	// works
	io_write(io, USART_TX_Buf, 12);		// works
}

static void tx_cb_USART_0(const struct usart_async_descriptor *const io_descr)	// reaches this
{
	/* Transfer completed */
	//gpio_toggle_pin_level(LED0);	// if led toggles TX works - IRQ tested works
	gpio_toggle_pin_level(LED0);	// if led toggles TX works - DMA tested actually toggles too fast to see, TX confirmed on serial port
	//_dma_enable_transaction(0, true);	// this line here = big bug
}

void USART_0_setup(void)
{
	struct io_descriptor *io;
	static uint8_t USART_ok_msg[18] = "USART enabled OK\r\n";
	usart_async_register_callback(&USART_0, USART_ASYNC_TXC_CB, tx_cb_USART_0);		// works
	/*usart_async_register_callback(&USART_0, USART_ASYNC_RXC_CB, rx_cb);
	usart_async_register_callback(&USART_0, USART_ASYNC_ERROR_CB, err_cb);*/
	usart_async_get_io_descriptor(&USART_0, &io);	// works
	usart_async_enable(&USART_0);	// works
	io_write(io, USART_ok_msg, 18);	// works
}

static void BUTTON_pressed(void)	// works
{
	delay_ms(100);					// works
	//gpio_toggle_pin_level(LED0);	// works
	//io_write(io, USART_TX_Buf, 12);	// io descriptor error, no surprise
	//USART_transmit();
	//usart_async_enable(&USART_0);
	_dma_enable_transaction(0, true);	// works
}


void EXTERNAL_IRQ_5_setup(void)		// works
{
	ext_irq_register(BUTTON, BUTTON_pressed);	// works
}

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();			// works
	EXTERNAL_IRQ_5_setup();		// works
	USART_0_setup();			// works
	config_dma_channel_0();
	/* Replace with your application code */
	while (1) {
	}
}
